# RPM package


# How build locally

The RPM contains some macros that only rpkg understands.

GitQlient$ rpkg local --spec contrib/rpm/gitqlient.spec
