# QPinnableTabWidget
QPinnableTabWidget is a normal QTabWidget that allows you to pin and unpin tabs.

To pin a tab you either can use `QPinnableTabWidget::addPinnedTab` programatically or through the UI using the context menu that appears when you left click on a tab.
