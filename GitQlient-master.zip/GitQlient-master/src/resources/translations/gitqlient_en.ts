<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>AGitServerItemList</name>
    <message>
        <location filename="../../git_server/AGitServerItemList.cpp" line="28"/>
        <source>Page: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddCodeReviewDialog</name>
    <message>
        <location filename="../../git_server/AddCodeReviewDialog.ui" line="14"/>
        <source>Add review</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/AddCodeReviewDialog.ui" line="25"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/AddCodeReviewDialog.ui" line="45"/>
        <location filename="../../git_server/AddCodeReviewDialog.cpp" line="21"/>
        <source>Add comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/AddCodeReviewDialog.cpp" line="24"/>
        <source>Approve PR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/AddCodeReviewDialog.cpp" line="27"/>
        <source>Request changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/AddCodeReviewDialog.cpp" line="52"/>
        <source>Empty comment!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/AddCodeReviewDialog.cpp" line="53"/>
        <source>The body cannot be empty when adding a comment or requesting changes.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddSubmoduleDlg</name>
    <message>
        <location filename="../../branches/AddSubmoduleDlg.ui" line="14"/>
        <source>Add new submodule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/AddSubmoduleDlg.ui" line="20"/>
        <source>Set URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/AddSubmoduleDlg.ui" line="27"/>
        <source>Set name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/AddSubmoduleDlg.ui" line="34"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/AddSubmoduleDlg.ui" line="54"/>
        <source>Accept</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AmendWidget</name>
    <message>
        <location filename="../../commits/AmendWidget.cpp" line="20"/>
        <source>Amend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/AmendWidget.cpp" line="94"/>
        <source>Impossible to commit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/AmendWidget.cpp" line="95"/>
        <source>There are files with conflicts. Please, resolve the conflicts first.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BlameWidget</name>
    <message>
        <location filename="../../big_widgets/BlameWidget.cpp" line="121"/>
        <source>No info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/BlameWidget.cpp" line="221"/>
        <source>Copy SHA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/BlameWidget.cpp" line="224"/>
        <source>Show file diff</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/BlameWidget.cpp" line="230"/>
        <source>Show commit diff</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BranchContextMenu</name>
    <message>
        <location filename="../../branches/BranchContextMenu.cpp" line="22"/>
        <source>Pull</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchContextMenu.cpp" line="23"/>
        <source>Fetch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchContextMenu.cpp" line="24"/>
        <source>Push</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchContextMenu.cpp" line="28"/>
        <source>Push force</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchContextMenu.cpp" line="32"/>
        <source>Create branch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchContextMenu.cpp" line="33"/>
        <source>Create &amp;&amp; checkout branch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchContextMenu.cpp" line="35"/>
        <source>Checkout branch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchContextMenu.cpp" line="39"/>
        <source>Merge %1 into %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchContextMenu.cpp" line="45"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchContextMenu.cpp" line="46"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchContextMenu.cpp" line="69"/>
        <location filename="../../branches/BranchContextMenu.cpp" line="140"/>
        <source>Error while pulling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchContextMenu.cpp" line="70"/>
        <location filename="../../branches/BranchContextMenu.cpp" line="141"/>
        <source>There were problems during the pull operation. Please, see the detailed description for more information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchContextMenu.cpp" line="93"/>
        <source>Fetch failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchContextMenu.cpp" line="93"/>
        <source>There were some problems while fetching. Please try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchContextMenu.cpp" line="116"/>
        <source>Error while pushing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchContextMenu.cpp" line="117"/>
        <source>There were problems during the push operation. Please, see the detailed description for more information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchContextMenu.cpp" line="185"/>
        <source>Delete master?!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchContextMenu.cpp" line="185"/>
        <source>You are not allowed to delete remote master.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchContextMenu.cpp" line="189"/>
        <source>Delete branch!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchContextMenu.cpp" line="189"/>
        <source>Are you sure you want to delete the branch?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchContextMenu.cpp" line="204"/>
        <source>Delete a branch failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchContextMenu.cpp" line="205"/>
        <source>There were some problems while deleting the branch:&lt;br&gt;&lt;br&gt; %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BranchDlg</name>
    <message>
        <location filename="../../aux_widgets/BranchDlg.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/BranchDlg.ui" line="20"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/BranchDlg.ui" line="27"/>
        <source>Set the branch name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/BranchDlg.ui" line="47"/>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/BranchDlg.ui" line="61"/>
        <source>Same as remote branch name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/BranchDlg.cpp" line="28"/>
        <source>Create branch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/BranchDlg.cpp" line="31"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/BranchDlg.cpp" line="35"/>
        <source>Create and checkout branch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/BranchDlg.cpp" line="39"/>
        <source>Create branch at commit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/BranchDlg.cpp" line="43"/>
        <source>Stash branch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/BranchDlg.cpp" line="48"/>
        <source>Push upstream branch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/BranchDlg.cpp" line="49"/>
        <source>Push</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/BranchDlg.cpp" line="106"/>
        <source>Error on branch action!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/BranchDlg.cpp" line="107"/>
        <source>There were problems during the branch operation. Please, see the detailed description for more information.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BranchTreeWidget</name>
    <message>
        <location filename="../../branches/BranchTreeWidget.cpp" line="92"/>
        <source>Error while checking out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchTreeWidget.cpp" line="93"/>
        <source>There were problems during the checkout operation. Please, see the detailed description for more information.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BranchesWidget</name>
    <message>
        <location filename="../../branches/BranchesWidget.cpp" line="81"/>
        <source>Local</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchesWidget.cpp" line="83"/>
        <source>Master</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchesWidget.cpp" line="84"/>
        <source>Origin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchesWidget.cpp" line="91"/>
        <source>Remote</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchesWidget.cpp" line="122"/>
        <source>Tags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchesWidget.cpp" line="162"/>
        <source>Stashes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchesWidget.cpp" line="163"/>
        <source>(0)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchesWidget.cpp" line="200"/>
        <source>Submodules</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchesWidget.cpp" line="227"/>
        <source>Show minimalist view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchesWidget.cpp" line="628"/>
        <source>Remove tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchesWidget.cpp" line="639"/>
        <source>Push tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchesWidget.cpp" line="678"/>
        <source>Add submodule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchesWidget.cpp" line="690"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchesWidget.cpp" line="701"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BranchesWidgetMinimal</name>
    <message>
        <location filename="../../branches/BranchesWidgetMinimal.cpp" line="32"/>
        <source>Full view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchesWidgetMinimal.cpp" line="52"/>
        <source>Local branches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchesWidgetMinimal.cpp" line="61"/>
        <source>Remote branches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchesWidgetMinimal.cpp" line="70"/>
        <source>Tags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchesWidgetMinimal.cpp" line="79"/>
        <source>Stashes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/BranchesWidgetMinimal.cpp" line="88"/>
        <source>Submodules</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CodeReviewComment</name>
    <message>
        <location filename="../../git_server/CodeReviewComment.cpp" line="58"/>
        <source> %1 days ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CodeReviewComment.cpp" line="58"/>
        <source> today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CodeReviewComment.cpp" line="59"/>
        <source> on %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CommitChangesWidget</name>
    <message>
        <location filename="../../commits/CommitChangesWidget.ui" line="14"/>
        <source>Commit changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/CommitChangesWidget.ui" line="114"/>
        <source>Unstaged files </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/CommitChangesWidget.ui" line="121"/>
        <location filename="../../commits/CommitChangesWidget.ui" line="316"/>
        <location filename="../../commits/CommitChangesWidget.ui" line="559"/>
        <source>(0)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/CommitChangesWidget.ui" line="190"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/CommitChangesWidget.ui" line="203"/>
        <source>Commit selected files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/CommitChangesWidget.ui" line="206"/>
        <source>&amp;Amend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/CommitChangesWidget.ui" line="209"/>
        <source>Alt+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/CommitChangesWidget.ui" line="309"/>
        <source>Untracked files </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/CommitChangesWidget.ui" line="396"/>
        <source>Summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/CommitChangesWidget.ui" line="427"/>
        <source>Author name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/CommitChangesWidget.ui" line="434"/>
        <source>Author email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/CommitChangesWidget.ui" line="552"/>
        <source>Staged files </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/CommitChangesWidget.ui" line="648"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/CommitChangesWidget.cpp" line="106"/>
        <source>Commit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/CommitChangesWidget.cpp" line="373"/>
        <source>(conflicts)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/CommitChangesWidget.cpp" line="451"/>
        <source> (conflicts)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CommitHistoryContextMenu</name>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="65"/>
        <source>Stash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="66"/>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="117"/>
        <source>Push</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="69"/>
        <source>Pop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="73"/>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="200"/>
        <source>See diff</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="78"/>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="80"/>
        <source>Branch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="83"/>
        <source>Tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="86"/>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="206"/>
        <source>Export as patch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="91"/>
        <source>Checkout commit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="105"/>
        <source>Amend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="109"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="111"/>
        <source>Patch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="114"/>
        <source>Commit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="120"/>
        <source>Pull</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="123"/>
        <source>Fetch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="128"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="130"/>
        <source>Soft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="133"/>
        <source>Mixed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="136"/>
        <source>Hard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="141"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="143"/>
        <source>Commit SHA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="147"/>
        <source>Commit title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="179"/>
        <source>Merge PR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="188"/>
        <source>Show PR detailed view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="209"/>
        <source>Copy all SHA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="261"/>
        <source>Patch generated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="262"/>
        <source>&lt;p&gt;The patch has been generated!&lt;/p&gt;&lt;p&gt;&lt;b&gt;Commit:&lt;/b&gt;&lt;/p&gt;&lt;p&gt;%1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Destination:&lt;/b&gt; %2&lt;/p&gt;&lt;p&gt;&lt;b&gt;File names:&lt;/b&gt;&lt;/p&gt;&lt;p&gt;%3&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="318"/>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="349"/>
        <source>Error while checking out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="319"/>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="350"/>
        <source>There were problems during the checkout operation. Please, see the detailed description for more information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="377"/>
        <source>Error while cherry-pick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="378"/>
        <source>There were problems during the cherry-pich operation. Please, see the detailed description for more information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="390"/>
        <source>Select a patch to apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="432"/>
        <source>Error while pushing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="433"/>
        <source>There were problems during the push operation. Please, see the detailed description for more information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="462"/>
        <source>Error while pulling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="463"/>
        <source>There were problems during the pull operation. Please, see the detailed description for more information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="566"/>
        <source>%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="573"/>
        <source>Checkout branch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="575"/>
        <source>New Branch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="575"/>
        <source>Checkout new branch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="592"/>
        <source>Merge %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryContextMenu.cpp" line="602"/>
        <source>Cherry pick commit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CommitHistoryModel</name>
    <message>
        <location filename="../../history/CommitHistoryModel.cpp" line="82"/>
        <source>&lt;p&gt;Status: &lt;b&gt;detached&lt;/b&gt;&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryModel.cpp" line="87"/>
        <source>&lt;p&gt;&lt;b&gt;Local: &lt;/b&gt;%1&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryModel.cpp" line="92"/>
        <source>&lt;p&gt;&lt;b&gt;Remote: &lt;/b&gt;%1&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryModel.cpp" line="97"/>
        <source>&lt;p&gt;&lt;b&gt;Tags: &lt;/b&gt;%1&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryModel.cpp" line="109"/>
        <source>&lt;p&gt;Commit signed!&lt;/p&gt;&lt;p&gt; GPG key: %1&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../history/CommitHistoryModel.cpp" line="114"/>
        <source>&lt;p&gt;&lt;b&gt;PR state: &lt;/b&gt;%1.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConfigWidget</name>
    <message>
        <location filename="../../config/ConfigWidget.cpp" line="29"/>
        <source>OPEN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/ConfigWidget.cpp" line="30"/>
        <source>CLONE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/ConfigWidget.cpp" line="31"/>
        <source>NEW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/ConfigWidget.cpp" line="71"/>
        <source>GitQlient %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/ConfigWidget.cpp" line="97"/>
        <source>About GitQlient...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/ConfigWidget.cpp" line="101"/>
        <source>Source code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/ConfigWidget.cpp" line="104"/>
        <source>Get the source code in GitHub</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/ConfigWidget.cpp" line="106"/>
        <source>Report an issue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/ConfigWidget.cpp" line="109"/>
        <source>Report an issue in GitHub</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/ConfigWidget.cpp" line="173"/>
        <source>Loading repository...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/ConfigWidget.cpp" line="191"/>
        <source>Recent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/ConfigWidget.cpp" line="212"/>
        <location filename="../../config/ConfigWidget.cpp" line="255"/>
        <source>Clear list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/ConfigWidget.cpp" line="234"/>
        <source>Most used</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/ConfigWidget.cpp" line="296"/>
        <source>Error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/ConfigWidget.cpp" line="301"/>
        <source>GitQlient, pronounced as git+client (/gɪtˈklaɪənt/) is a multi-platform Git client. With GitQlient you will be able to add commits, branches and manage all the options Git provides. &lt;br&gt;&lt;br&gt;Once a fork of QGit, GitQlient has followed is own path and is currently develop and maintain by Francesc M. You can download the code from &lt;a href=&apos;https://github.com/francescmm/GitQlient&apos;&gt;GitHub&lt;/a&gt;. If you find any bug or problem, please report it in &lt;a href=&apos;https://github.com/francescmm/GitQlient/issues&apos;&gt;the issues page&lt;/a&gt; so I can fix it as soon as possible.&lt;br&gt;&lt;br&gt;If you want to integrate GitQlient into QtCreator, there I also provide a plugin that you can download from &lt;a href=&apos;https://github.com/francescmm/GitQlient/releases&apos;&gt;here&lt;/a&gt;. Just make sure you pick the right version and follow the instructions in the main page of the repo.&lt;br&gt;&lt;br&gt;GitQlient can be compiled from Qt 5.12 on.&lt;br&gt;&lt;br&gt;Copyright &amp;copy; 2019 - 2020 GitQlient (Francesc Martínez)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/ConfigWidget.cpp" line="314"/>
        <source>About GitQlient v%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Controls</name>
    <message>
        <location filename="../../big_widgets/Controls.cpp" line="47"/>
        <source>WARNING: There is a merge pending to be commited! Click here to solve it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/Controls.cpp" line="59"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/Controls.cpp" line="66"/>
        <source>Diff</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/Controls.cpp" line="74"/>
        <source>Blame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/Controls.cpp" line="81"/>
        <source>Fetch all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/Controls.cpp" line="84"/>
        <source>Prune</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/Controls.cpp" line="89"/>
        <source>Pull</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/Controls.cpp" line="111"/>
        <source>Push</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/Controls.cpp" line="116"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/Controls.cpp" line="121"/>
        <source>Config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/Controls.cpp" line="167"/>
        <source>New version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/Controls.cpp" line="256"/>
        <source>Error while pulling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/Controls.cpp" line="257"/>
        <source>There were problems during the pull operation. Please, see the detailed description for more information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/Controls.cpp" line="333"/>
        <source>Error while pushing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/Controls.cpp" line="334"/>
        <source>There were problems during the push operation. Please, see the detailed description for more information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/Controls.cpp" line="361"/>
        <source>Error while poping a stash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/Controls.cpp" line="362"/>
        <source>There were problems during the stash pop operation. Please, see the detailed description for more information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/Controls.cpp" line="410"/>
        <source>Pull Request</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/Controls.cpp" line="418"/>
        <source>Merge Request</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CreateIssueDlg</name>
    <message>
        <location filename="../../git_server/CreateIssueDlg.ui" line="32"/>
        <source>New Issue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreateIssueDlg.ui" line="40"/>
        <source>Title:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreateIssueDlg.ui" line="47"/>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreateIssueDlg.ui" line="54"/>
        <source>Milestone:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreateIssueDlg.ui" line="61"/>
        <source>Labels:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreateIssueDlg.ui" line="91"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreateIssueDlg.ui" line="111"/>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreateIssueDlg.cpp" line="42"/>
        <source>Empty fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreateIssueDlg.cpp" line="42"/>
        <source>Please, complete all fields with valid data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreateIssueDlg.cpp" line="80"/>
        <source>Select milestone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreateIssueDlg.cpp" line="104"/>
        <source>Issue created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreateIssueDlg.cpp" line="105"/>
        <source>The issue has been created. You can &lt;a href=&quot;%1&quot;&gt;find it here&lt;/a&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreateIssueDlg.cpp" line="114"/>
        <source>API access error!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CreatePullRequestDlg</name>
    <message>
        <location filename="../../git_server/CreatePullRequestDlg.ui" line="26"/>
        <source>Create Pull Request</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreatePullRequestDlg.ui" line="34"/>
        <source>Title:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreatePullRequestDlg.ui" line="44"/>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreatePullRequestDlg.ui" line="54"/>
        <source>Origin branch (HEAD):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreatePullRequestDlg.ui" line="64"/>
        <source>Destination branch (base):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreatePullRequestDlg.ui" line="74"/>
        <source>Milestone:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreatePullRequestDlg.ui" line="84"/>
        <source>Labels:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreatePullRequestDlg.ui" line="101"/>
        <source>Mark as draft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreatePullRequestDlg.ui" line="108"/>
        <source>Allow maintainers to modify the Pull Request</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreatePullRequestDlg.ui" line="122"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreatePullRequestDlg.ui" line="142"/>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreatePullRequestDlg.cpp" line="70"/>
        <source>Empty fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreatePullRequestDlg.cpp" line="70"/>
        <source>Please, complete all fields with valid data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreatePullRequestDlg.cpp" line="74"/>
        <source>Error in the branch selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreatePullRequestDlg.cpp" line="75"/>
        <source>The base branch and the branch to merge from cannot be the same. Please, select different branches.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreatePullRequestDlg.cpp" line="153"/>
        <source>Pull Request created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreatePullRequestDlg.cpp" line="154"/>
        <source>The Pull Request has been created. You can &lt;a href=&quot;%1&quot;&gt;find it here&lt;/a&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/CreatePullRequestDlg.cpp" line="166"/>
        <source>API access error!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CreateRepoDlg</name>
    <message>
        <location filename="../../aux_widgets/CreateRepoDlg.ui" line="20"/>
        <source>Open repository after %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/CreateRepoDlg.ui" line="30"/>
        <source>Browse...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/CreateRepoDlg.ui" line="37"/>
        <source>Config Git user for this repo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/CreateRepoDlg.ui" line="47"/>
        <source>Git user name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/CreateRepoDlg.ui" line="54"/>
        <source>Repository destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/CreateRepoDlg.ui" line="61"/>
        <source>URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/CreateRepoDlg.ui" line="68"/>
        <source>Repository name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/CreateRepoDlg.ui" line="75"/>
        <source>Accept</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/CreateRepoDlg.ui" line="82"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/CreateRepoDlg.ui" line="102"/>
        <source>Git user email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/CreateRepoDlg.cpp" line="32"/>
        <source>%1 repository</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/CreateRepoDlg.cpp" line="33"/>
        <source>Initialize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/CreateRepoDlg.cpp" line="33"/>
        <source>Clone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/CreateRepoDlg.cpp" line="116"/>
        <source>You need to provider a URL to clone a repository.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/CreateRepoDlg.cpp" line="118"/>
        <source>Nor URL provided</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/CreateRepoDlg.cpp" line="145"/>
        <source>Error when %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DiffWidget</name>
    <message>
        <location filename="../../big_widgets/DiffWidget.cpp" line="110"/>
        <source>No modifications</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/DiffWidget.cpp" line="110"/>
        <source>There are no content modifications for this file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/DiffWidget.cpp" line="157"/>
        <source>No diff to show!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/DiffWidget.cpp" line="158"/>
        <source>There is no diff to show between commit SHAs {%1} and {%2}</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FakeCloseButton</name>
    <message>
        <location filename="../../QPinnableTabWidget/FakeCloseButton.cpp" line="11"/>
        <source>Close Tab</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileBlameWidget</name>
    <message>
        <location filename="../../diff/FileBlameWidget.cpp" line="43"/>
        <source>Select a file to blame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileBlameWidget.cpp" line="56"/>
        <source>Current SHA:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileBlameWidget.cpp" line="57"/>
        <source>Previous SHA:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileBlameWidget.cpp" line="98"/>
        <source>File not in Git</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileBlameWidget.cpp" line="99"/>
        <source>The file {%1} is not under Git control version. You cannot blame it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileBlameWidget.cpp" line="235"/>
        <source>more than 1 year ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileBlameWidget.cpp" line="237"/>
        <source> days ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileBlameWidget.cpp" line="239"/>
        <source>yesterday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileBlameWidget.cpp" line="241"/>
        <source> hours ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileBlameWidget.cpp" line="243"/>
        <source>1 hour ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileBlameWidget.cpp" line="245"/>
        <source> minutes ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileBlameWidget.cpp" line="247"/>
        <source>1 minute ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileBlameWidget.cpp" line="249"/>
        <source> secs ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileBlameWidget.cpp" line="274"/>
        <source>Local changes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileContextMenu</name>
    <message>
        <location filename="../../commits/FileContextMenu.cpp" line="13"/>
        <source>History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/FileContextMenu.cpp" line="16"/>
        <source>Blame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/FileContextMenu.cpp" line="18"/>
        <source>Diff</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/FileContextMenu.cpp" line="25"/>
        <source>Edit file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/FileContextMenu.cpp" line="30"/>
        <source>Copy path</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileDiffView</name>
    <message>
        <location filename="../../diff/FileDiffView.cpp" line="258"/>
        <source>Stage chunk</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileDiffWidget</name>
    <message>
        <location filename="../../diff/FileDiffWidget.cpp" line="68"/>
        <location filename="../../diff/FileDiffWidget.cpp" line="78"/>
        <source>Press Enter to search a text... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileDiffWidget.cpp" line="122"/>
        <source>Return to the view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileDiffWidget.cpp" line="126"/>
        <source>Previous change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileDiffWidget.cpp" line="129"/>
        <source>Next change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileDiffWidget.cpp" line="135"/>
        <source>Edit file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileDiffWidget.cpp" line="140"/>
        <source>Full file view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileDiffWidget.cpp" line="145"/>
        <source>Split file view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileDiffWidget.cpp" line="150"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileDiffWidget.cpp" line="155"/>
        <source>Stage file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileDiffWidget.cpp" line="159"/>
        <source>Revert changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileDiffWidget.cpp" line="426"/>
        <source>Revert all changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileDiffWidget.cpp" line="427"/>
        <source>Please, take into account that this will revert all the changes you have performed so far.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileDiffWidget.cpp" line="515"/>
        <source>Changes staged!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileDiffWidget.cpp" line="515"/>
        <source>The chunk has been successfully staged.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileDiffWidget.cpp" line="528"/>
        <source>Stage failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileDiffWidget.cpp" line="529"/>
        <source>The chunk couldn&apos;t be applied:
%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileEditor</name>
    <message>
        <location filename="../../diff/FileEditor.cpp" line="54"/>
        <source>Unsaved changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileEditor.cpp" line="55"/>
        <source>The current text was modified. Do you want to save the changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileEditor.cpp" line="57"/>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FileEditor.cpp" line="58"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FullDiffWidget</name>
    <message>
        <location filename="../../diff/FullDiffWidget.cpp" line="85"/>
        <source>Press Enter to search a text... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FullDiffWidget.cpp" line="105"/>
        <source>Previous change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/FullDiffWidget.cpp" line="108"/>
        <source>Next change</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GeneralConfigDlg</name>
    <message>
        <location filename="../../config/GeneralConfigDlg.cpp" line="29"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/GeneralConfigDlg.cpp" line="30"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/GeneralConfigDlg.cpp" line="31"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/GeneralConfigDlg.cpp" line="34"/>
        <source>Git location...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/GeneralConfigDlg.cpp" line="72"/>
        <source>Disable logs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/GeneralConfigDlg.cpp" line="74"/>
        <source>Set log level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/GeneralConfigDlg.cpp" line="76"/>
        <source>Styles schema</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/GeneralConfigDlg.cpp" line="78"/>
        <source>Git location (if not in PATH):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/GeneralConfigDlg.cpp" line="81"/>
        <source>Export config...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/GeneralConfigDlg.cpp" line="86"/>
        <source>Import config...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/GeneralConfigDlg.cpp" line="117"/>
        <source>Reset needed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/GeneralConfigDlg.cpp" line="118"/>
        <source>You need to restart GitQlient to see the changes in the styles applid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/GeneralConfigDlg.cpp" line="134"/>
        <source>Select a config file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/GeneralConfigDlg.cpp" line="156"/>
        <source>External configuration loaded!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/GeneralConfigDlg.cpp" line="157"/>
        <source>The configuration has been loaded successfully. Remember to apply the changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/GeneralConfigDlg.cpp" line="167"/>
        <source>Select a folder...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/GeneralConfigDlg.cpp" line="190"/>
        <source>Configuration exported!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/GeneralConfigDlg.cpp" line="191"/>
        <source>The configuration has been stored in {%1}</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GitCache</name>
    <message>
        <location filename="../../cache/GitCache.cpp" line="197"/>
        <source>No local changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../cache/GitCache.cpp" line="197"/>
        <source>Local changes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GitConfigDlg</name>
    <message>
        <location filename="../../config/GitConfigDlg.ui" line="14"/>
        <source>Git Config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/GitConfigDlg.ui" line="35"/>
        <source>Global Git name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/GitConfigDlg.ui" line="42"/>
        <source>Global Git email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/GitConfigDlg.ui" line="49"/>
        <source>User global settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/GitConfigDlg.ui" line="56"/>
        <source>Local Git name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../config/GitConfigDlg.ui" line="63"/>
        <source>Local Git email</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GitQlient</name>
    <message>
        <location filename="../../big_widgets/GitQlient.cpp" line="46"/>
        <source>Open new repository</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/GitQlient.cpp" line="235"/>
        <source>Not a Git repository</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/GitQlient.cpp" line="236"/>
        <source>The selected path is not a Git repository. Please make sure you opened the correct directory.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GitQlientRepo</name>
    <message>
        <location filename="../../big_widgets/GitQlientRepo.cpp" line="268"/>
        <source>Loading repository...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/GitQlientRepo.cpp" line="494"/>
        <source>Branch not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/GitQlientRepo.cpp" line="495"/>
        <source>The branch couldn&apos;t be found. Please, make sure you fetched and have the latest changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/GitQlientRepo.cpp" line="539"/>
        <source>Commit error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/GitQlientRepo.cpp" line="539"/>
        <source>Failed to commit changes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GitQlientUpdater</name>
    <message>
        <location filename="../../aux_widgets/GitQlientUpdater.cpp" line="41"/>
        <source>New version of GitQlient!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/GitQlientUpdater.cpp" line="42"/>
        <source>There is a new version of GitQlient available. Your current vrsion is {%1} and the new one is {%2}. You can read more about the new changes in the detailed description.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/GitQlientUpdater.cpp" line="46"/>
        <source>Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/GitQlientUpdater.cpp" line="94"/>
        <source>New version available!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/GitQlientUpdater.cpp" line="95"/>
        <source>There is a new version of GitQlient available but your OS doesn&apos;t have a binary built. If you want to get the latest version, pleas &lt;a href=&apos;https://github.com/francescmm/GitQlient/releases/tag/v%1&apos;&gt;get the source code from GitHub&lt;/a&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/GitQlientUpdater.cpp" line="144"/>
        <source>Downloading...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/GitQlientUpdater.cpp" line="144"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GitServerWidget</name>
    <message>
        <location filename="../../big_widgets/GitServerWidget.cpp" line="67"/>
        <source>Create a new issue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/GitServerWidget.cpp" line="72"/>
        <source>Create a new %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/GitServerWidget.cpp" line="77"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HistoryWidget</name>
    <message>
        <location filename="../../big_widgets/HistoryWidget.cpp" line="62"/>
        <location filename="../../big_widgets/HistoryWidget.cpp" line="394"/>
        <source>Working branch: &lt;b&gt;%1&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/HistoryWidget.cpp" line="115"/>
        <source>Press Enter to search by SHA or log message...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/HistoryWidget.cpp" line="159"/>
        <source>Cherry-pick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/HistoryWidget.cpp" line="166"/>
        <source>Show all branches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/HistoryWidget.cpp" line="334"/>
        <source>No diff available!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/HistoryWidget.cpp" line="334"/>
        <source>There is no diff to show.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/HistoryWidget.cpp" line="364"/>
        <source>Not found!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/HistoryWidget.cpp" line="364"/>
        <source>No commits where found based on the search text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/HistoryWidget.cpp" line="419"/>
        <source>Merge failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/HistoryWidget.cpp" line="420"/>
        <source>There were problems during the merge. Please, see the detailed description for more information.&lt;br&gt;&lt;br&gt;GitQlient will show the merge helper tool.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/HistoryWidget.cpp" line="440"/>
        <source>Merge successful</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/HistoryWidget.cpp" line="441"/>
        <source>The merge was successfully done. See the detailed description for more information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/HistoryWidget.cpp" line="450"/>
        <source>Merge status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/HistoryWidget.cpp" line="451"/>
        <source>There were problems during the merge. Please, see the detailed description for more information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/HistoryWidget.cpp" line="509"/>
        <source>Error while cherry-pick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/HistoryWidget.cpp" line="510"/>
        <source>There were problems during the cherry-pick operation. Please, see the detailed description for more information.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InitialRepoConfig</name>
    <message>
        <location filename="../../aux_widgets/InitialRepoConfig.ui" line="14"/>
        <source>Repo config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/InitialRepoConfig.ui" line="20"/>
        <source> last commits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/InitialRepoConfig.ui" line="68"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/InitialRepoConfig.ui" line="77"/>
        <source>Max. commits to retrieve (0 for all)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/InitialRepoConfig.ui" line="84"/>
        <source>Update submodules when pull</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/InitialRepoConfig.ui" line="91"/>
        <source> minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/InitialRepoConfig.ui" line="104"/>
        <source>Auto-Fetch interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/InitialRepoConfig.ui" line="111"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;In this new version, GitQlient includes some new parameters to help you to configure the repository. Please take a moment to change them if you&apos;d like.&lt;/p&gt;&lt;p&gt;If you already have configured some of them, they will show the already set value.&lt;/p&gt;&lt;p&gt;You can modify these values at any moment using the &lt;span style=&quot; font-style:italic;&quot;&gt;Config &lt;/span&gt;button in the top icons list of GitQlient.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/InitialRepoConfig.ui" line="131"/>
        <source>The interval is expected to be in minutes. Choose a value between 0 (for disabled) and 60.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/InitialRepoConfig.ui" line="141"/>
        <source>Prune when fetch</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IssueDetailedView</name>
    <message>
        <location filename="../../git_server/IssueDetailedView.cpp" line="37"/>
        <source>Detailed View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueDetailedView.cpp" line="43"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueDetailedView.cpp" line="49"/>
        <source>Comments view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueDetailedView.cpp" line="58"/>
        <source>Changes view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueDetailedView.cpp" line="66"/>
        <source>Commits view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueDetailedView.cpp" line="77"/>
        <source>Start review</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueDetailedView.cpp" line="81"/>
        <source>Only comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueDetailedView.cpp" line="82"/>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueDetailedView.cpp" line="89"/>
        <source>Review: Approve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueDetailedView.cpp" line="91"/>
        <location filename="../../git_server/IssueDetailedView.cpp" line="98"/>
        <source>The comments will be part of a review</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueDetailedView.cpp" line="96"/>
        <source>Review: Request changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueDetailedView.cpp" line="108"/>
        <source>Add new comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueDetailedView.cpp" line="116"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueDetailedView.cpp" line="201"/>
        <source> %1 days ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueDetailedView.cpp" line="201"/>
        <source> today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueDetailedView.cpp" line="202"/>
        <source> on %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueDetailedView.cpp" line="204"/>
        <source>Created by &lt;b&gt;%1&lt;/b&gt;%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueDetailedView.cpp" line="250"/>
        <source>Close issue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueDetailedView.cpp" line="250"/>
        <source>Are you sure you want to close the issue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueDetailedView.cpp" line="266"/>
        <source>Comment review</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueDetailedView.cpp" line="271"/>
        <source>Approve review</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueDetailedView.cpp" line="276"/>
        <source>Request changes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IssueItem</name>
    <message>
        <location filename="../../git_server/IssueItem.cpp" line="50"/>
        <source>Created by </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueItem.cpp" line="59"/>
        <source> %1 days ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueItem.cpp" line="60"/>
        <source> on %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/IssueItem.cpp" line="105"/>
        <source>Assigned to </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IssuesList</name>
    <message>
        <location filename="../../git_server/IssuesList.cpp" line="16"/>
        <source>Issues</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Jenkins::JenkinsJobPanel</name>
    <message>
        <location filename="../../jenkins/JenkinsJobPanel.cpp" line="44"/>
        <source>Open job in Jenkins...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../jenkins/JenkinsJobPanel.cpp" line="45"/>
        <source>Trigger build</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../jenkins/JenkinsJobPanel.cpp" line="107"/>
        <source>Request in progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../jenkins/JenkinsJobPanel.cpp" line="108"/>
        <source>There is a request in progress. Please, wait until the builds and stages for this job have been loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../jenkins/JenkinsJobPanel.cpp" line="309"/>
        <source>Find text... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../jenkins/JenkinsJobPanel.cpp" line="392"/>
        <source>Build</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../jenkins/JenkinsJobPanel.cpp" line="403"/>
        <source>Build with params</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../jenkins/JenkinsJobPanel.cpp" line="448"/>
        <source>Update requested</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../jenkins/JenkinsJobPanel.cpp" line="449"/>
        <source>The build has been triggered and the information will be refreshed in 10 secs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../jenkins/JenkinsJobPanel.cpp" line="477"/>
        <source>Artifacts for #%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../jenkins/JenkinsJobPanel.cpp" line="509"/>
        <source>File already exists!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../jenkins/JenkinsJobPanel.cpp" line="510"/>
        <source>The file already exists in %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../jenkins/JenkinsJobPanel.cpp" line="519"/>
        <source>File downloaded!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../jenkins/JenkinsJobPanel.cpp" line="520"/>
        <source>The file (%1) has been downloaded in: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../jenkins/JenkinsJobPanel.cpp" line="525"/>
        <source>File download error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../jenkins/JenkinsJobPanel.cpp" line="525"/>
        <source>The file (%1) couldn&apos;t be downloaded.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MergePullRequestDlg</name>
    <message>
        <location filename="../../git_server/MergePullRequestDlg.ui" line="14"/>
        <location filename="../../git_server/MergePullRequestDlg.ui" line="66"/>
        <source>Merge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/MergePullRequestDlg.ui" line="22"/>
        <source>Title:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/MergePullRequestDlg.ui" line="32"/>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/MergePullRequestDlg.ui" line="46"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/MergePullRequestDlg.cpp" line="53"/>
        <source>Empty fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/MergePullRequestDlg.cpp" line="53"/>
        <source>Please, complete all fields with valid data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/MergePullRequestDlg.cpp" line="72"/>
        <source>PR merged!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/MergePullRequestDlg.cpp" line="72"/>
        <source>The pull request has been merged.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/MergePullRequestDlg.cpp" line="89"/>
        <source>API access error!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MergeWidget</name>
    <message>
        <location filename="../../big_widgets/MergeWidget.cpp" line="33"/>
        <source>Merge &amp;&amp; Commit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/MergeWidget.cpp" line="34"/>
        <source>Abort merge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/MergeWidget.cpp" line="43"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/MergeWidget.cpp" line="69"/>
        <source>Conflicts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/MergeWidget.cpp" line="72"/>
        <source>Changes to be commited</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/MergeWidget.cpp" line="180"/>
        <source>Error aborting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/MergeWidget.cpp" line="181"/>
        <source>There were problems during the aborting the merge. Please, see the detailed description for more information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/MergeWidget.cpp" line="219"/>
        <source>Error while merging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../big_widgets/MergeWidget.cpp" line="220"/>
        <source>There were problems during the merge operation. Please, see the detailed description for more information.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PomodoroButton</name>
    <message>
        <location filename="../../aux_widgets/PomodoroButton.cpp" line="25"/>
        <source>Pomodoro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/PomodoroButton.cpp" line="29"/>
        <source>Options...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/PomodoroButton.cpp" line="42"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/PomodoroButton.cpp" line="225"/>
        <source>Time for a break!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/PomodoroButton.cpp" line="225"/>
        <source>It&apos;s time to do a break. Are you ready?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/PomodoroButton.cpp" line="261"/>
        <location filename="../../aux_widgets/PomodoroButton.cpp" line="290"/>
        <source>Time to work!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/PomodoroButton.cpp" line="261"/>
        <location filename="../../aux_widgets/PomodoroButton.cpp" line="290"/>
        <source>It&apos;s time to go back to work. Are you ready?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PomodoroConfigDlg</name>
    <message>
        <location filename="../../aux_widgets/PomodoroConfigDlg.ui" line="14"/>
        <source>Pomodoro configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/PomodoroConfigDlg.ui" line="41"/>
        <source>Pomodoro duration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/PomodoroConfigDlg.ui" line="61"/>
        <source>25</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/PomodoroConfigDlg.ui" line="68"/>
        <location filename="../../aux_widgets/PomodoroConfigDlg.ui" line="125"/>
        <location filename="../../aux_widgets/PomodoroConfigDlg.ui" line="179"/>
        <source>minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/PomodoroConfigDlg.ui" line="98"/>
        <source>Break duration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/PomodoroConfigDlg.ui" line="118"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/PomodoroConfigDlg.ui" line="152"/>
        <source>Long break duration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/PomodoroConfigDlg.ui" line="172"/>
        <source>15</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/PomodoroConfigDlg.ui" line="209"/>
        <source>Long break after:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/PomodoroConfigDlg.ui" line="216"/>
        <source> pomodoros</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/PomodoroConfigDlg.ui" line="239"/>
        <source>Enable alarm sound:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/PomodoroConfigDlg.ui" line="253"/>
        <source>Reset counter when stop:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrCommentsList</name>
    <message>
        <location filename="../../git_server/PrCommentsList.cpp" line="61"/>
        <location filename="../../git_server/PrCommentsList.cpp" line="535"/>
        <source>Add your comment...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/PrCommentsList.cpp" line="64"/>
        <location filename="../../git_server/PrCommentsList.cpp" line="538"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/PrCommentsList.cpp" line="65"/>
        <location filename="../../git_server/PrCommentsList.cpp" line="539"/>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/PrCommentsList.cpp" line="131"/>
        <source>Assigned to </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/PrCommentsList.cpp" line="146"/>
        <source>Unassigned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/PrCommentsList.cpp" line="271"/>
        <source> %1 days ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/PrCommentsList.cpp" line="271"/>
        <source> today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/PrCommentsList.cpp" line="272"/>
        <source> on %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/PrCommentsList.cpp" line="340"/>
        <source>Comment by </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/PrCommentsList.cpp" line="393"/>
        <source>&lt;b&gt;%1&lt;/b&gt; (%2) requested changes to the PR </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/PrCommentsList.cpp" line="399"/>
        <source>&lt;b&gt;%1&lt;/b&gt; (%2) approved the PR </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/PrCommentsList.cpp" line="411"/>
        <source>&lt;b&gt;%1&lt;/b&gt; (%2) reviewed the PR and added some comments </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/PrCommentsList.cpp" line="515"/>
        <source>Outdated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/PrCommentsList.cpp" line="530"/>
        <source>Add new comment</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrCommitsList</name>
    <message>
        <location filename="../../git_server/PrCommitsList.cpp" line="86"/>
        <source> %1 days ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/PrCommitsList.cpp" line="86"/>
        <source> today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/PrCommitsList.cpp" line="87"/>
        <source> on %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/PrCommitsList.cpp" line="89"/>
        <source>Committed by &lt;b&gt;%1&lt;/b&gt; %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/PrCommitsList.cpp" line="115"/>
        <source>Copied!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrList</name>
    <message>
        <location filename="../../git_server/PrList.cpp" line="16"/>
        <source>Pull Requests</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PullDlg</name>
    <message>
        <location filename="../../aux_widgets/PullDlg.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/PullDlg.ui" line="36"/>
        <source>Would you like to pull the last changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/PullDlg.cpp" line="53"/>
        <source>Error while pulling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/PullDlg.cpp" line="54"/>
        <source>There were problems during the pull operation. Please, see the detailed description for more information.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../diff/DiffHelper.h" line="210"/>
        <source>Text not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../diff/DiffHelper.h" line="210"/>
        <source>Text not found.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QPinnableTabWidget</name>
    <message>
        <location filename="../../QPinnableTabWidget/QPinnableTabWidget.cpp" line="193"/>
        <source>Unpin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../QPinnableTabWidget/QPinnableTabWidget.cpp" line="195"/>
        <source>Pin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../QPinnableTabWidget/QPinnableTabWidget.cpp" line="197"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RealCloseButton</name>
    <message>
        <location filename="../../QPinnableTabWidget/RealCloseButton.cpp" line="14"/>
        <source>Close Tab</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RepoConfigDlg</name>
    <message>
        <location filename="../../aux_widgets/RepoConfigDlg.ui" line="14"/>
        <source>Repository configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/RepoConfigDlg.ui" line="60"/>
        <source>Config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/RepoConfigDlg.ui" line="88"/>
        <source> last commits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/RepoConfigDlg.ui" line="116"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/RepoConfigDlg.ui" line="138"/>
        <source>Max. commits to retrieve (0 for all)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/RepoConfigDlg.ui" line="145"/>
        <source>Update submodules when pull</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/RepoConfigDlg.ui" line="152"/>
        <source>Auto-Fetch interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/RepoConfigDlg.ui" line="159"/>
        <source>The interval is expected to be in minutes. Choose a value between 0 (for disabled) and 60.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/RepoConfigDlg.ui" line="182"/>
        <source>Prune when fetch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/RepoConfigDlg.ui" line="199"/>
        <source>Cache space used:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/RepoConfigDlg.ui" line="206"/>
        <source> minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/RepoConfigDlg.ui" line="236"/>
        <source>Enable pomodoro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/RepoConfigDlg.ui" line="243"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Run clang-format before commit&lt;br/&gt;(Requires clang-format)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/RepoConfigDlg.ui" line="250"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/RepoConfigDlg.ui" line="265"/>
        <source>Build System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/RepoConfigDlg.ui" line="271"/>
        <source>Enable build system view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/RepoConfigDlg.ui" line="285"/>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/RepoConfigDlg.ui" line="292"/>
        <source>Token:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/RepoConfigDlg.ui" line="322"/>
        <source>Endpoint URL:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/RepoConfigDlg.ui" line="337"/>
        <source>Git Local</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../aux_widgets/RepoConfigDlg.ui" line="346"/>
        <source>Git Global</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RepositoryViewDelegate</name>
    <message>
        <location filename="../../history/RepositoryViewDelegate.cpp" line="145"/>
        <source>Copied!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ServerConfigDlg</name>
    <message>
        <location filename="../../git_server/ServerConfigDlg.ui" line="26"/>
        <source>Server configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/ServerConfigDlg.ui" line="32"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/ServerConfigDlg.ui" line="65"/>
        <source>Set the user name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/ServerConfigDlg.ui" line="79"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/ServerConfigDlg.ui" line="89"/>
        <source>Test token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/ServerConfigDlg.ui" line="112"/>
        <source>Set the repository endpoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/ServerConfigDlg.ui" line="137"/>
        <source>Set the user token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/ServerConfigDlg.cpp" line="82"/>
        <source>How to get a token?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/ServerConfigDlg.cpp" line="159"/>
        <source>Token confirmed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../git_server/ServerConfigDlg.cpp" line="165"/>
        <source>API access error!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StagedFilesList</name>
    <message>
        <location filename="../../commits/StagedFilesList.cpp" line="25"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/StagedFilesList.cpp" line="27"/>
        <source>See changes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StashesContextMenu</name>
    <message>
        <location filename="../../branches/StashesContextMenu.cpp" line="16"/>
        <source>Branch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/StashesContextMenu.cpp" line="17"/>
        <source>Drop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/StashesContextMenu.cpp" line="18"/>
        <source>Clear all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/StashesContextMenu.cpp" line="39"/>
        <source>Error while droping stash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/StashesContextMenu.cpp" line="40"/>
        <source>There were problems during the stash drop operation. Please, see the detailed description for more information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/StashesContextMenu.cpp" line="58"/>
        <source>Error while branch stash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/StashesContextMenu.cpp" line="59"/>
        <source>There were problems during the branch stash operation. Please, see the detailed description for more information.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TagDlg</name>
    <message>
        <location filename="../../branches/TagDlg.ui" line="14"/>
        <source>Create tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/TagDlg.ui" line="20"/>
        <source>Tag name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/TagDlg.ui" line="27"/>
        <source>Tag message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/TagDlg.ui" line="34"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../branches/TagDlg.ui" line="54"/>
        <source>Accept</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UnstagedMenu</name>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="20"/>
        <source>See changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="21"/>
        <source>Blame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="25"/>
        <source>Edit file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="31"/>
        <source>Mark as resolved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="40"/>
        <source>Stage file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="42"/>
        <source>Revert file changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="44"/>
        <location filename="../../commits/UnstagedMenu.cpp" line="60"/>
        <location filename="../../commits/UnstagedMenu.cpp" line="109"/>
        <source>Ignoring file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="44"/>
        <source>Are you sure you want to revert the changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="57"/>
        <source>Ignore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="59"/>
        <source>Ignore file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="61"/>
        <source>Are you sure you want to add the file to the black list?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="72"/>
        <source>Ignore extension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="74"/>
        <source>Ignoring extension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="74"/>
        <source>Are you sure you want to add the file extension to the black list?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="88"/>
        <source>Ignore containing folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="90"/>
        <source>Ignoring folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="90"/>
        <source>Are you sure you want to add the containing folder to the black list?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="106"/>
        <source>Add all files to commit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="107"/>
        <source>Revert all changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="109"/>
        <source>Are you sure you want to undo all the changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="133"/>
        <source>File added to .gitignore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="134"/>
        <source>The file has been added to the ignore list in the file .gitignore.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="139"/>
        <source>Unable to add the entry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UnstagedMenu.cpp" line="140"/>
        <source>It was impossible to add the entry in the .gitignore file.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UntrackedMenu</name>
    <message>
        <location filename="../../commits/UntrackedMenu.cpp" line="17"/>
        <source>Stage file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UntrackedMenu.cpp" line="18"/>
        <source>Delete file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UntrackedMenu.cpp" line="20"/>
        <source>Ignore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UntrackedMenu.cpp" line="22"/>
        <source>Ignore file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UntrackedMenu.cpp" line="23"/>
        <location filename="../../commits/UntrackedMenu.cpp" line="37"/>
        <source>Ignoring file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UntrackedMenu.cpp" line="24"/>
        <source>Are you sure you want to add the file to the black list?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UntrackedMenu.cpp" line="35"/>
        <source>Ignore extension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UntrackedMenu.cpp" line="37"/>
        <source>Are you sure you want to add the file extension to the black list?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UntrackedMenu.cpp" line="51"/>
        <source>Ignore containing folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UntrackedMenu.cpp" line="53"/>
        <source>Ignoring folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UntrackedMenu.cpp" line="53"/>
        <source>Are you sure you want to add the containing folder to the black list?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UntrackedMenu.cpp" line="100"/>
        <source>File added to .gitignore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UntrackedMenu.cpp" line="101"/>
        <source>The file has been added to the ignore list in the file .gitignore.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UntrackedMenu.cpp" line="106"/>
        <source>Unable to add the entry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/UntrackedMenu.cpp" line="107"/>
        <source>It was impossible to add the entry in the .gitignore file.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WipWidget</name>
    <message>
        <location filename="../../commits/WipWidget.cpp" line="59"/>
        <source>Impossible to commit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../commits/WipWidget.cpp" line="60"/>
        <source>There are files with conflicts. Please, resolve the conflicts first.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
