HOMEBREW_NO_AUTO_UPDATE=1 brew install glew
HOMEBREW_NO_AUTO_UPDATE=1 brew install clang-format
HOMEBREW_NO_AUTO_UPDATE=1 brew install qt
HOMEBREW_NO_AUTO_UPDATE=1 brew install create-dmg
HOMEBREW_NO_AUTO_UPDATE=1 brew uninstall --force java
